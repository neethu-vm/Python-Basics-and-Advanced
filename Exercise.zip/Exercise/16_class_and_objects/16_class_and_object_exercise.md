## Exercise: Class and Objects

1. Create a sample class named Employee with two attributes id and name 

```
employee :
    id
    name
```
object initializes id and name dynamically for every Employee object created.
 
```
emp = Employee(1, "coder")
```

2. Use del property to first delete id attribute and then the entire object


[Solution](https://github.com/codebasics/py/blob/master/Basics/Exercise/16_class_and_objects/16_class_and_objects.py)
