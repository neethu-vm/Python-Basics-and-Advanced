## Exercise: Multiple Inheritance

Real Life Example :
1. Create multiple inheritance on teacher,student and youtuber.


```
Q. if we have created teacher and now one student joins master degree with becoming teacher then what??

Ans :  just make subclass from  teacher so that student will become teacher
```

2. Now student is teacher as well as youtuber then what???


```
-just use multiple inheritance for these three relations

```



[Solution](https://github.com/codebasics/py/blob/master/Basics/Exercise/18_multiple_inheritance/18_multiple_inheritance.py)
