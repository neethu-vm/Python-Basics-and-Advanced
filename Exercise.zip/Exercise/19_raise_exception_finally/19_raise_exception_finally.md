## Exercise: Raise Exception And Finally

1. Create a custom exception AdultException.

2. Create a class Person with attributes name and age in it.

3. Create a function get_minor_age() in the class. It throws an exception if the person is adult otherwise returns age.

4. Create a function display_person() which prints the age and name of a person.
```
let us say,

if age>18 
    he is major
else
    raise exception

create cusomException named ismajor and raise it if age<18.
```



[Solution](https://github.com/codebasics/py/blob/master/Basics/Exercise/19_raise_exception_finally/19_raise_exception_finally.py)
