## Exercise: Iterators

1. Create an iterator for fibonacci series in such a way that each next returns the next element from fibonacci series.
2. The iterator should stop when it reaches a `limit` defined in the constructor.



[Solution](https://github.com/codebasics/py/blob/master/Basics/Exercise/20_Iterators/20_Iterators.py)
