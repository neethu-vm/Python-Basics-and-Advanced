## Exercise: Generators

1. Print Square Sequence using yield


```
    Create Generator method such that every time it will returns a next square number

for exmaple : 1 4 9 16 ..

     
```



[Solution](https://github.com/codebasics/py/blob/master/Basics/Exercise/21_generators/21_generators.py)
