## Exercise: Commandline Argument Processing using argparse

1. Take subject marks as command line arguments 

```
example: 
    python3 cmd.py --physics 60 --chemistry 70 --maths 90
```

2. Find average marks for the three subjects using command line input of marks.


[Solution](https://github.com/codebasics/py/blob/master/Basics/Exercise/24_argparse/24_argparse.py)
