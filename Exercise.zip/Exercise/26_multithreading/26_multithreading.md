## Exercise: Multithreading

1. Create any multithreaded code using for loop for creating multithreads

```
for i in range(10):
    th = Thread(target=func_name, args=(i, ))
    
```


2. print total active threads in multithreaded code using threading.active_count()



[Solution](https://github.com/codebasics/py/blob/master/Basics/Exercise/26_multithreading/26_multithreading.py)
